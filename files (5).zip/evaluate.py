"""Retrieval hit-rate harness.
Questions with "answerable": false are skipped here - they test hallucination,
so run them through `python ask.py` and check that the model says it doesn't know.
A 'hit' = at least one of the top-k chunks comes from expected_source
AND contains expected_keyword (whitespace-insensitive, case-insensitive).
Usage: python evaluate.py [k ...]    e.g. python evaluate.py 3 5
"""
import json
import sys
from pathlib import Path

from rag_core import get_vectorstore


def norm(s: str) -> str:
    return " ".join(s.lower().split())


def hit_rate(questions, k):
    db = get_vectorstore()
    hits = 0
    for item in questions:
        docs = db.similarity_search(item["question"], k=k)
        ok = any(
            Path(d.metadata["source"]).name == item["expected_source"]
            and norm(item["expected_keyword"]) in norm(d.page_content)
            for d in docs
        )
        hits += ok
        print(f"  [{'HIT ' if ok else 'MISS'}] {item['question']}")
    return hits / len(questions)


if __name__ == "__main__":
    all_q = json.loads(Path("questions.json").read_text())
    questions = [q for q in all_q if q.get("answerable", True)]
    print(f"{len(questions)} answerable questions "
          f"({len(all_q) - len(questions)} unanswerable skipped)")
    for k in [int(a) for a in sys.argv[1:]] or [3, 5]:
        print(f"\n== top-k = {k} ==")
        print(f"hit rate: {hit_rate(questions, k):.0%}")
